MOSS — Anime Garden

1. Open index.html in a modern browser to preview the site.
2. The catalogue and search use the public Jikan API (MyAnimeList data). Internet is required.
3. Your watchlist is saved in this browser on this device using localStorage.
4. Trailer embeds are previews only. This starter does not host or provide unauthorised full anime episodes.
5. To publish it, upload index.html to a static host such as GitHub Pages or Netlify.

This is a front-end starter project; no backend or user accounts are included.
